const GM_KEY = "AIzaSyA5WpyjImkemkAiHkeZQYqHEc5ybF0uIIg";
const GM_API_GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json";
const DEFAULT_RADIUS = 160;
const DEFAULT_LAT = 21.0227731;
const DEFAULT_LNG = 105.8018581;
const COLORS = {
  success:  "#4caf50",
  danger:   "#ff9800",
  primary:  "#9c27b0",
  info:     "#00bcd4",
  danger:   "#f44336",
  default:  "#999999"
}
;
